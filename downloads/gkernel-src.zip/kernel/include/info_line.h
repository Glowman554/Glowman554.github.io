#ifndef INFO_LINE_H
#define INFO_LINE_H
void drawinfo(int tcount);
#endif
