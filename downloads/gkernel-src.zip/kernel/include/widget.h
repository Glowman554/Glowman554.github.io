#ifndef WIDGET_H
#define WIDGET_H

void create_error(int code);

#endif
