#ifndef KEYMAP_H
#define KEYMAP_H

#include <stdint.h>

char keymap_de(uint8_t key);

#endif