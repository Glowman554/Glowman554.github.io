#ifndef STDDEF_H
#define STDDEF_H

typedef __SIZE_TYPE__ size_t;

#endif
