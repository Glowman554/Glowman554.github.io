#ifndef CONFIG_H
#define CONFIG_H

#include <stdbool.h>

#define VERSION 			11
#define VENDOR 				"Glowman554"
#define AUTOEXEC 			"/progs/init.bin"
#define LIST_FILES_ON_BOOT 	false
#define SERIAL_DEBUG		true

#endif